test = {
  'name': 'Question 4_5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> news_writing_lines.take(range(2, 6))
          Line
          This eBook is for the use of anyone anywhere at no cost  ...
          almost no restrictions whatsoever.  You may copy it, giv ...
          re-use it under the terms of the Project Gutenberg Licen ...
          with this eBook or online at www.gutenberg.org
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
