test = {
  'name': 'Question 5_1',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> top_5_causes
          Cause of Death | Count
          HTD            | 957108
          CAN            | 822906
          OTH            | 637764
          STK            | 231897
          CLD            | 194961
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
