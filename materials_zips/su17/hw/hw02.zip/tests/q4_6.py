test = {
  'name': 'Question 4_6',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> weird_sum
          44920848562
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
