
test = {
  'name': 'Question 4_',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> Lebron_height_in_inches == 80
          True
          >>> Lebron_height_in_meters == 2.032
          True
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}