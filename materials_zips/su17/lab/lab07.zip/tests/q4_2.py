test = {
  'name': '',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> first_five_names_and_accel
          Vehicle Name    | Acceleration
          Prius (1st Gen) | 7.46
          Tino            | 8.2
          Prius (2nd Gen) | 7.97
          Insight         | 9.52
          Civic (1st Gen) | 7.04
          """,
          'hidden': False,
          'locked': False
        },
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
