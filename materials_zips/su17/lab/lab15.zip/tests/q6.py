test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> test_statistic_function = lambda tbl: np.mean(tbl.column("Interested in raising animals"))
          >>> abs(sample_once(649) - 0.91) < 0.02
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}