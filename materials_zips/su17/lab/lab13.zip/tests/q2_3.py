test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> convenience_sample.num_columns
          11
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> convenience_sample.num_rows
          44
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
